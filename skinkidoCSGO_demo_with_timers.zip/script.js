
function openCase(type) {
    const sound = document.getElementById('drop-sound');
    sound.play();
    
    const drops = [
        'AWP | Dragon Lore', 'AK-47 | Redline', 'M4A4 | Asimov', 'USP-S | Cortex', 'Karambit | Fade', 'P90 | Trigon'
    ];

    const randomDrop = drops[Math.floor(Math.random() * drops.length)];
    alert("🎉 Otworzyłeś skrzynkę: " + type + " i wygrałeś " + randomDrop + "!");
    showDropAnimation(randomDrop);
}

function showDropAnimation(dropItem) {
    const dropContainer = document.getElementById('drop-container');
    dropContainer.innerHTML = '🎉 Wygrałeś: ' + dropItem + '!';
    dropContainer.classList.add('show');
    setTimeout(() => dropContainer.classList.remove('show'), 5000);
}

window.onload = () => {
    // Tworzymy skrzynki poziomowe
    const levelCasesContainer = document.getElementById('level-cases');
    for (let i = 1; i <= 50; i++) {
        const div = document.createElement('div');
        div.className = 'case';
        div.innerHTML = '<h3>📦 Poziom ' + i + '</h3><p>0 zł</p><button onclick="openCase(\'level ' + i + '\')">Otwórz</button>';
        levelCasesContainer.appendChild(div);
    }
    
    // Darmowa skrzynka
    const freeCaseTimer = 24 * 60 * 60 * 1000; // 24h
    let lastOpened = localStorage.getItem('lastOpenedFreeCase') || 0;
    let timeLeft = freeCaseTimer - (Date.now() - lastOpened);
    
    if (timeLeft <= 0) {
        localStorage.setItem('lastOpenedFreeCase', Date.now());
        document.querySelector('.daily-free button').disabled = false;
    } else {
        document.querySelector('.daily-free button').disabled = true;
        const hoursLeft = Math.floor(timeLeft / (1000 * 60 * 60));
        const minutesLeft = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
        alert(`Darmowa skrzynka dostępna za: ${hoursLeft} godzin i ${minutesLeft} minut`);
    }
    
    // Poziomowy timer
    const levelTimer = 6 * 60 * 60 * 1000; // 6h
    let lastOpenedLevel = localStorage.getItem('lastOpenedLevel') || 0;
    let levelTimeLeft = levelTimer - (Date.now() - lastOpenedLevel);
    
    if (levelTimeLeft <= 0) {
        localStorage.setItem('lastOpenedLevel', Date.now());
    } else {
        alert(`Skrzynka za poziom dostępna za: ${Math.floor(levelTimeLeft / (1000 * 60 * 60))} godzin`);
    }
};
